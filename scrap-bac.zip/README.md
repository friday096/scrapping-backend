create .env file
`MONGO_URI=`

start the project with command  `npm run dev`