const SCRAP = require('../model/ScrapModel');
const constant = require('../utils/constant');
const puppeteer = require('puppeteer');
const path = require('path');
const fs = require('path');


module.exports = {
    createScrap: async (data, callback) => {
        const { url } = data;
        console.log('Backend URL:', url);
    
        try {
            // Launch Puppeteer and scrape the data
            const browser = await puppeteer.launch();
            const page = await browser.newPage();
            await page.goto(url, { waitUntil: 'networkidle2' });
    
            // Scraping data
            const scrapedData = await page.evaluate(() => {
                return {
                    name: document.querySelector('meta[property="og:site_name"]')?.content || document.title,
                    description: document.querySelector('meta[name="description"]')?.content || '',
                    logoUrl: document.querySelector('img, svg') ? (document.querySelector('img') ? document.querySelector('img').src : document.querySelector('svg').outerHTML) : '',
                    facebook: document.querySelector('a[href*="facebook.com"]')?.href || '',
                    linkedin: document.querySelector('a[href*="linkedin.com"]')?.href || '',
                    twitter: document.querySelector('a[href*="twitter.com"]')?.href || '',
                    instagram: document.querySelector('a[href*="instagram.com"]')?.href || '',
                    address: document.querySelector('.address')?.textContent || '',
                    phone: document.querySelector('a[href*="tel"]')?.textContent || '',
                    email: document.querySelector('a[href^="mailto:"]') ? document.querySelector('a[href^="mailto:"]').innerText : '',
                };
            });


            let logoPath = '';
            const header = await page.$('header');
            if (header) {
                const logo = await header.$('img[alt*="logo"], svg, link[rel="icon"]');
                console.log('Backend URL:', url);

                if (logo) {
                    logoPath = path.join(__dirname, `../public/images/logo-${Date.now()}.png`);
                    if (logo.nodeName === 'IMG') {
                        await logo.screenshot({ path: logoPath }); // Save logo screenshot if it's an image
                    } else if (logo.nodeName === 'SVG') {
                        // Serialize the SVG and save it as a PNG
                        const svgContent = await logo.evaluate(el => el.outerHTML);
                        fs.writeFileSync(logoPath.replace('.png', '.svg'), svgContent);
                        // Additional: Convert SVG to PNG if needed
                    }
                }
            }
    
            // Take a screenshot of half the page
            const bodyHandle = await page.$('body');
            const boundingBox = await bodyHandle.boundingBox();
            const screenshotPath = path.join(__dirname, `../public/images/screenshot-${Date.now()}.png`);
            
            await page.screenshot({
                path: screenshotPath,
                fullPage: true
            });
    
            await browser.close();
    

    
            // Create new scrap entry in the database
            // console.log('logoPath', logoPath)
            // console.log('xsSasa', screenshotPath.split('\\').pop())
            // return
            const newScrap = new SCRAP({
                url:url,
                name: scrapedData.name,
                description: scrapedData.description,
                logo: logoPath ? logoPath.split('\\').pop() : '', // Save relative path
                facebook: scrapedData.facebook,
                linkedin: scrapedData.linkedin,
                twitter: scrapedData.twitter,
                instagram: scrapedData.instagram,
                address: scrapedData.address,
                phone: scrapedData.phone,
                email: scrapedData.email,
                screenshot: screenshotPath.split('\\').pop(), // Save relative path of screenshot
            });
    
            await newScrap.save();
    
            callback(null, {
                status: constant.success_code,
                message: 'Scrap created successfully!',
                data: newScrap,
            });
    
        } catch (err) {
            console.error('Error during web scraping:', err.message);
            callback({
                status: constant.error_code,
                message: err.message,
            }, null);
        }
    },
    // Fetch all scraps
    getAllScraps: async (callback) => {
        try {
            const scraps = await SCRAP.find({ status: 1 }); // Fetch all active scraps
            callback(null, {
                status: constant.success_code,
                message: 'All scraps fetched successfully!',
                data: scraps,
            });
        } catch (err) {
            callback({
                status: constant.error_code,
                message: 'Failed to fetch scraps.',
            }, null);
        }
    },
    // Fetch a single scrap by ID
    getScrapById: async (id, callback) => {
        try {
            const scrap = await SCRAP.findById(id);

            if (!scrap) {
                return callback({
                    status: constant.error_code,
                    message: 'Scrap not found.',
                }, null);
            }

            callback(null, {
                status: constant.success_code,
                message: 'Scrap fetched successfully!',
                data: scrap,
            });
        } catch (err) {
            callback({
                status: constant.error_code,
                message: 'Failed to fetch scrap by ID.',
            }, null);
        }
    },

    //delete Scrap
    deleteScrap: async (ids, callback) =>{
        try {
            const result = await SCRAP.deleteMany({
                _id: { $in: ids } 
            });
    
            if (result.deletedCount > 0) {
                callback(null, {
                    status: constant.success_code,
                    message: `scrap deleted successfully!`,
                });
            } else {
                callback({
                    status: constant.error_code,
                    message: "No scraps found to delete!",
                }, null);
            }
        } catch (err) {
            // Return an error in the callback if something goes wrong
            callback({
                status: constant.error_code,
                message: err.message,
            }, null);
        }
    }
};
